<?php
declare(strict_types=1);

namespace Kazoo\Exceptions;

class InvalidAuthException extends HttpException {}
