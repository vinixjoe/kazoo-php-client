<?php
declare(strict_types=1);

namespace Kazoo\Exceptions;

class ValidationException extends HttpException {}
