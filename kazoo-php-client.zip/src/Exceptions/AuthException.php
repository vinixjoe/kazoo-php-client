<?php
declare(strict_types=1);

namespace Kazoo\Exceptions;

use Exception;

class AuthException extends Exception {}
