<?php
declare(strict_types=1);

namespace Kazoo\Exceptions;

class NotFoundException extends HttpException {}
